Kaalaverse client photo assets
================================

Upload the JPEG files in this folder to the `assets/` folder in:
salmanulfariskk555-gif/mvp-artist-yes

Suggested page use:
- wildlife-tiger-deer.jpg — wildlife artwork
- behind-the-lens-mountain.jpg — artist/photographer profile
- wildlife-hornbill-wide.jpg — wildlife artwork
- wildlife-green-snake.jpg — wildlife artwork
- wildlife-hornbill-flight.jpg — wildlife artwork
- wildlife-frog.jpg — wildlife artwork
- nature-sunset.jpg — nature artwork
- wildlife-hornbill-portrait.jpg — wildlife artwork
- performing-arts-dancer.jpg — performing arts gallery

One duplicate upload was excluded. These files are optimized JPEG copies; the original photos were not edited beyond resizing/compression.
Artwork prices must be confirmed by the client before publishing. Do not treat suggested prices as approved.
