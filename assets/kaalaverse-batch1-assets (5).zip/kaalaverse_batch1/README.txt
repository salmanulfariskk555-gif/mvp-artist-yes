Kaalaverse – Batch 1 artwork assets
24 optimized WebP images and a CSV with suggested titles/prices.
Suggested prices are placeholders, not independent art valuations.
Upload the assets/ folder into the website repository and merge the CSV data into the existing artwork listing without deleting current items.
